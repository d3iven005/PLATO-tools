#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({
    "font.size": 14,       
    "axes.titlesize": 16,    
    "axes.labelsize": 16,    
    "xtick.labelsize": 14,  
    "ytick.labelsize": 14, 
    "legend.fontsize": 13,  
})

DISP_ROOT = "gamma_disp_pm"
DELTA_ANG = 0.01

# ---- supercell ----
NATOM_UC = 2                 # B2 primitive basis atoms (Mg,O) in your ordering
N1 = N2 = N3 = 4             # 6x6x6
NATOM_SC = NATOM_UC * N1 * N2 * N3   # 432

SPECIES = ["Mg", "O"]
MASS_AMU = {"Mg": 24.305, "O": 15.999}

# lattice constant (simple cubic conventional a, in Angstrom)
A_BOHR = 5
BOHR_TO_ANG = 0.529177210903
A = A_BOHR * BOHR_TO_ANG  # Angstrom

# band path sampling
NSEG = 50

# DOS sampling
NQ = 18
SIGMA = 10.0          # cm^-1 Gaussian broadening
KEEP_NEGATIVE = True

# optional: enforce acoustic sum rule (recommended)
APPLY_ASR = True

# plot range
YMIN, YMAX = -350, 600
# ============================================

# ---------- constants ----------
RY_TO_EV = 13.605693009
EV_TO_J = 1.602176634e-19
A0_M = 0.529177210903e-10
ANG_M = 1.0e-10
C_CM_S = 2.99792458e10
RY_A0_TO_N = (RY_TO_EV * EV_TO_J) / A0_M
AMU_TO_KG = 1.66053906660e-27


def parse_forces_plato(out_path: str) -> np.ndarray:
    """
    Parse PLATO forces:
      BEGIN_FORCES
        fx fy fz   (Ry/a0)
      END_FORCES
    Return (natom, 3) in Ry/a0, where natom is read from the block.
    """
    with open(out_path, "r") as f:
        lines = f.readlines()

    ib = ie = None
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "BEGIN_FORCES":
            ib = i + 1
        elif s == "END_FORCES":
            ie = i
            break

    if ib is None or ie is None or ie <= ib:
        raise RuntimeError(f"FORCES block not found or empty in {out_path}")

    n = ie - ib
    forces = np.zeros((n, 3), dtype=float)
    for i in range(n):
        fx, fy, fz = map(float, lines[ib + i].split())
        forces[i] = [fx, fy, fz]
    return forces


def out_file(disp_id: int, tag: str) -> str:
    """
    Your naming:
      gamma_disp_pm/disp_001_m/mgo_1_m.out
      gamma_disp_pm/disp_001_p/mgo_1_p.out
    """
    return os.path.join(DISP_ROOT, f"disp_{disp_id:03d}_{tag}", f"mgo_{disp_id}_{tag}.out")


def check_displacement_files():
    nd = NATOM_UC * 3
    for did in range(1, nd + 1):
        for tag in ("p", "m"):
            f = out_file(did, tag)
            if not os.path.isfile(f):
                raise RuntimeError(f"Missing output: {f}")


def build_ifc() -> np.ndarray:
    """
    Build real-space IFCs from central difference.

    Storage:
      Phi[l, k, alpha, k0, beta]
    where:
      l  : cell index in supercell (0..NCELL-1)
      k  : basis atom in that cell (0..NATOM_UC-1)
      k0 : displaced basis atom in reference cell (0..NATOM_UC-1)
      alpha,beta : Cartesian
    """
    NCELL = NATOM_SC // NATOM_UC
    if NCELL != N1 * N2 * N3:
        raise RuntimeError(
            f"NCELL mismatch: NATOM_SC//NATOM_UC={NCELL}, but N1*N2*N3={N1*N2*N3}."
        )

    Phi = np.zeros((NCELL, NATOM_UC, 3, NATOM_UC, 3), dtype=float)
    delta_m = DELTA_ANG * ANG_M

    disp_id = 1
    for k0 in range(NATOM_UC):
        for beta in range(3):
            Fp = parse_forces_plato(out_file(disp_id, "p"))
            Fm = parse_forces_plato(out_file(disp_id, "m"))

            if Fp.shape != (NATOM_SC, 3) or Fm.shape != (NATOM_SC, 3):
                raise RuntimeError(
                    f"Forces shape mismatch in disp {disp_id}: "
                    f"Fp {Fp.shape}, Fm {Fm.shape}, expected {(NATOM_SC,3)}"
                )

            # dF/dx in N/m
            dF = (Fp - Fm) * RY_A0_TO_N / (2.0 * delta_m)

            # mapping i_sc -> (cell l, basis k)
            # assumes ordering: (cell0 Mg,O)(cell1 Mg,O)...
            for i_sc in range(NATOM_SC):
                l = i_sc // NATOM_UC
                k = i_sc % NATOM_UC
                for alpha in range(3):
                    Phi[l, k, alpha, k0, beta] = -dF[i_sc, alpha]

            disp_id += 1

    return Phi


def apply_asr(Phi: np.ndarray) -> np.ndarray:
    """
    Acoustic sum rule (ASR):
      sum_{l,k} Phi[l,k,alpha,k0,beta] = 0  for every (k0,beta,alpha)

    Enforce by adjusting the on-site block of the displaced atom in the reference cell:
      Phi[0,k0,alpha,k0,beta] -= sum_{l,k} Phi[l,k,alpha,k0,beta]
    """
    Phi2 = Phi.copy()
    NCELL = Phi.shape[0]
    for k0 in range(NATOM_UC):
        for beta in range(3):
            for alpha in range(3):
                s = 0.0
                for l in range(NCELL):
                    for k in range(NATOM_UC):
                        s += Phi2[l, k, alpha, k0, beta]
                Phi2[0, k0, alpha, k0, beta] -= s
    return Phi2


def _wrapped_shifts():
    """
    Build supercell translation vectors R_l in the SAME enumeration order
    as your atom listing (iz fastest, then iy, then ix), but wrapped to
    the minimal-image representation (important for band-path q values).
    """
    a1 = np.array([A, 0.0, 0.0])
    a2 = np.array([0.0, A, 0.0])
    a3 = np.array([0.0, 0.0, A])

    shifts = []
    # enumerate in the same order as build_ifc expects (cell index l)
    for ix in range(N1):
        for iy in range(N2):
            for iz in range(N3):
                # wrap index to [-N/2, N/2] (minimal image)
                sx = ix if ix <= N1 // 2 else ix - N1
                sy = iy if iy <= N2 // 2 else iy - N2
                sz = iz if iz <= N3 // 2 else iz - N3
                shifts.append(sx * a1 + sy * a2 + sz * a3)

    return shifts


def dynamical_matrix(Phi: np.ndarray, q: np.ndarray) -> np.ndarray:
    """
    Mass-weighted D(q) for simple-cubic Bravais lattice with lattice constant A
    and a 2-atom basis (Mg,O).

    IMPORTANT FIX:
      Use wrapped minimal-image translation vectors R for the phase exp(i q·R),
      otherwise band-path q (continuous) will get wrong phases.
    """
    masses = np.array([MASS_AMU[s] for s in SPECIES], dtype=float) * AMU_TO_KG
    mvec = np.repeat(masses, 3)  # length 6

    D = np.zeros((3 * NATOM_UC, 3 * NATOM_UC), dtype=complex)

    shifts = _wrapped_shifts()
    if len(shifts) != Phi.shape[0]:
        raise RuntimeError(f"shifts ({len(shifts)}) != Phi.shape[0] ({Phi.shape[0]})")

    for l, R in enumerate(shifts):
        phase = np.exp(1j * np.dot(q, R))
        for k in range(NATOM_UC):
            for kp in range(NATOM_UC):
                for a in range(3):
                    for b in range(3):
                        ii = 3 * k + a
                        jj = 3 * kp + b
                        D[ii, jj] += Phi[l, k, a, kp, b] * phase

    D = D / np.sqrt(np.outer(mvec, mvec))
    return 0.5 * (D + D.conj().T)


def freqs_and_eigvecs_cm1(D: np.ndarray): 
    """ Same convention as your PLATO script: diagonalize D.real, map negative w^2 to negative 
    frequency. """ 
    w2, V = np.linalg.eigh(D.real) 
    w = np.sign(w2) * np.sqrt(np.abs(w2)) 
    freqs_cm = (w / (2 * np.pi)) / C_CM_S 
    return freqs_cm, V


def interpolate_kpath(points, nseg=40):
    klist, x = [], []
    xpos = 0.0
    for i in range(len(points) - 1):
        p0 = np.array(points[i], dtype=float)
        p1 = np.array(points[i + 1], dtype=float)
        seg_len = np.linalg.norm(p1 - p0)
        for j in range(nseg):
            t = j / nseg
            klist.append((1 - t) * p0 + t * p1)
            x.append(xpos)
            xpos += seg_len / nseg
    klist.append(np.array(points[-1], dtype=float))
    x.append(xpos)
    return np.array(klist), np.array(x)


def gaussian(x, mu, sigma):
    return np.exp(-0.5 * ((x - mu) / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))


def make_qmesh(nq=18):
    twopi_a = 2 * np.pi / A
    grid = np.arange(nq, dtype=float) / nq
    qlist = []
    for i in grid:
        for j in grid:
            for k in grid:
                qlist.append(twopi_a * np.array([i, j, k], dtype=float))
    return np.array(qlist)


def compute_band(Phi):
    """
    simple cubic BZ path: Γ – X – M – Γ – R – X
    """
    twopi_a = 2 * np.pi / A
    G = twopi_a * np.array([0.0, 0.0, 0.0])
    X = twopi_a * np.array([0.0, 0.5, 0.0])
    M = twopi_a * np.array([0.5, 0.5, 0.0])
    R = twopi_a * np.array([0.5, 0.5, 0.5])

    points = [G, X, M, G, R, X]
    labels = ["Γ", "X", "M", "Γ", "R", "X"]

    klist, x = interpolate_kpath(points, nseg=NSEG)

    bands = []
    for q in klist:
        Dq = dynamical_matrix(Phi, q)
        freqs_cm, _ = freqs_and_eigvecs_cm1(Dq)
        bands.append(np.sort(freqs_cm))
    bands = np.array(bands)

    step = len(x) // (len(labels) - 1)
    ticks = [x[i * step] for i in range(len(labels))]
    return x, bands, ticks, labels


def compute_dos(Phi, nq=18, sigma=10.0, fgrid=None, keep_negative=True):
    qmesh = make_qmesh(nq=nq)

    idx_Mg = np.arange(0, 3, dtype=int)
    idx_O  = np.arange(3, 6, dtype=int)

    freqs_all = []
    w_tot_all, w_Mg_all, w_O_all = [], [], []

    for q in qmesh:
        Dq = dynamical_matrix(Phi, q)
        freqs_cm, V = freqs_and_eigvecs_cm1(Dq)

        for m in range(freqs_cm.shape[0]):
            f = freqs_cm[m]
            if (not keep_negative) and (f < 0.0):
                continue

            e = V[:, m]
            wMg = np.sum(np.abs(e[idx_Mg])**2)
            wO  = np.sum(np.abs(e[idx_O])**2)
            wTot = wMg + wO

            freqs_all.append(f)
            w_tot_all.append(wTot)
            w_Mg_all.append(wMg)
            w_O_all.append(wO)

    freqs_all = np.array(freqs_all, dtype=float)
    w_tot_all = np.array(w_tot_all, dtype=float)
    w_Mg_all  = np.array(w_Mg_all, dtype=float)
    w_O_all   = np.array(w_O_all, dtype=float)

    if fgrid is None:
        fgrid = np.linspace(YMIN, YMAX, 2200)

    dos_tot = np.zeros_like(fgrid, dtype=float)
    dos_Mg  = np.zeros_like(fgrid, dtype=float)
    dos_O   = np.zeros_like(fgrid, dtype=float)

    for f, wt, wmg, wo in zip(freqs_all, w_tot_all, w_Mg_all, w_O_all):
        g = gaussian(fgrid, f, sigma)
        dos_tot += wt  * g
        dos_Mg  += wmg * g
        dos_O   += wo  * g

    # normalize total DOS area to 3N (here N = NATOM_UC)
    area = np.trapz(dos_tot, fgrid)
    if area > 0:
        target = 3 * NATOM_UC
        scale = target / area
        dos_tot *= scale
        dos_Mg  *= scale
        dos_O   *= scale

    return fgrid, dos_tot, dos_Mg, dos_O


def main():
    print(f"A (Ang) = {A:.6f}")
    print(f"Supercell: {N1}x{N2}x{N3}, NATOM_SC={NATOM_SC}, NATOM_UC={NATOM_UC}")

    check_displacement_files()
    Phi = build_ifc()

    if APPLY_ASR:
        Phi = apply_asr(Phi)
        print("ASR applied.")

    # quick sanity: Gamma acoustic modes should be near 0 after ASR
    Dg = dynamical_matrix(Phi, np.zeros(3))
    print("max|D.imag| at Gamma =", np.max(np.abs(Dg.imag)))
    fg, _ = freqs_and_eigvecs_cm1(Dg)
    print("Gamma lowest 6 freqs (cm^-1):", np.sort(fg)[:6])

    # band + dos
    x, bands, ticks, labels = compute_band(Phi)

    fgrid = np.linspace(YMIN, YMAX, 2200)
    fgrid, dos_tot, dos_Mg, dos_O = compute_dos(
        Phi, nq=NQ, sigma=SIGMA, fgrid=fgrid, keep_negative=KEEP_NEGATIVE
    )

    fig, (ax_band, ax_dos) = plt.subplots(
        1, 2, figsize=(10, 4),
        gridspec_kw={"width_ratios": [3.2, 1.2]},
        sharey=True
    )

    # left: dispersion
    for i in range(bands.shape[1]):
        ax_band.plot(x, bands[:, i], color="black", lw=1.2)

    ax_band.set_xticks(ticks)
    ax_band.set_xticklabels(labels)
    for t in ticks[1:-1]:
        ax_band.axvline(t, color="gray", lw=0.6)

    ax_band.set_ylim(YMIN, YMAX)
    ax_band.set_xlim(0, x[-1])
    ax_band.set_ylabel("Frequency (cm$^{-1}$)")
    ax_band.margins(x=0)
    ax_band.set_title("bcc-MgO phonon dispersion (DFTB+MACE)")

    # right: DOS
    ax_dos.plot(dos_tot, fgrid, lw=1.6, label="Total")
    ax_dos.plot(dos_Mg,  fgrid, lw=1.2, label="Mg")
    ax_dos.plot(dos_O,   fgrid, lw=1.2, label="O")
    ax_dos.set_xlim(left=0)

    ax_dos.set_xlabel("DoS (a.u.)")
    ax_dos.set_title("PDoS")
    ax_dos.grid(True, axis="x", lw=0.4, alpha=0.4)
    ax_dos.legend(frameon=False, fontsize=9)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()

