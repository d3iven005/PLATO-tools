import os
import shutil
import subprocess
from concurrent.futures import ProcessPoolExecutor, as_completed

# ============================================
PLATO_BIN = os.path.expanduser(
    #"~/Desktop/Plato-master_20250911version/bin/tb3"
    "tb3"
)

BASE_INPUT = "mgo_444.in"  
MODEL_FILE = "mace.model"

WORKDIR = "gamma_disp_pm"  
DELTA = 0.01               

NATOM_SC = 128              
NATOM_UC = 2             
NPROC = 6               
# =====================================================


def read_input(filename):
    with open(filename, "r") as f:
        return f.readlines()


def write_input(filename, lines):
    with open(filename, "w") as f:
        f.writelines(lines)


def find_atoms_block(lines):
    n_atom = None
    atom_start = None

    for i, line in enumerate(lines):
        if line.strip() == "NAtom":
            n_atom = int(lines[i + 1].strip())
            break
    if n_atom is None:
        raise RuntimeError("NAtom not found")

    for i, line in enumerate(lines):
        if line.strip() == "Atoms":
            atom_start = i + 1
            break
    if atom_start is None:
        raise RuntimeError("Atoms block not found")

    atoms = []
    for j in range(n_atom):
        parts = lines[atom_start + j].split()
        atoms.append([
            parts[0],
            float(parts[1]),
            float(parts[2]),
            float(parts[3])
        ])

    return atom_start, atoms


# -----------------------------------------------------
def run_one_disp(task):
    """
    task = (disp_id, ia, idir, sign, base_lines, atom_start, atoms)
    """
    disp_id, ia, idir, sign, base_lines, atom_start, atoms = task
    tag = "p" if sign > 0 else "m"

    subdir = os.path.join(WORKDIR, f"disp_{disp_id:03d}_{tag}")
    os.makedirs(subdir, exist_ok=True)


    shutil.copy(MODEL_FILE, subdir)

    new_lines = base_lines.copy()
    for ja, (elem, x, y, z) in enumerate(atoms):
        coords = [x, y, z]
        if ja == ia:
            coords[idir] += sign * DELTA
        new_lines[atom_start + ja] = (
            f"{elem:<2s}  {coords[0]:16.8f}  "
            f"{coords[1]:16.8f}  {coords[2]:16.8f}\n"
        )

    in_name = f"mgo_{disp_id}_{tag}.in"
    write_input(os.path.join(subdir, in_name), new_lines)

    print(f"[RUN] disp {disp_id:03d} {tag} | atom {ia} dir {idir}")
    subprocess.run(
        [PLATO_BIN, f"mgo_{disp_id}_{tag}"],
        cwd=subdir,
        check=True
    )

    return disp_id, tag


# -----------------------------------------------------
def main():
    if not os.path.isfile(BASE_INPUT):
        raise RuntimeError(f"{BASE_INPUT} not found")
    if not os.path.isfile(MODEL_FILE):
        raise RuntimeError(f"{MODEL_FILE} not found")

    base_lines = read_input(BASE_INPUT)
    atom_start, atoms = find_atoms_block(base_lines)

    if len(atoms) != NATOM_SC:
        raise RuntimeError(
            f"Expect {NATOM_SC} atoms, found {len(atoms)}"
        )

    os.makedirs(WORKDIR, exist_ok=True)

    tasks = []
    disp_id = 1
    directions = [0, 1, 2]  # x,y,z

    for ia in range(NATOM_UC):
        for idir in directions:
            for sign in (+1, -1):
                tasks.append(
                    (disp_id, ia, idir, sign,
                     base_lines, atom_start, atoms)
                )
            disp_id += 1

    print(f"Total displacement jobs: {len(tasks)}")


    with ProcessPoolExecutor(max_workers=NPROC) as executor:
        futures = [executor.submit(run_one_disp, t) for t in tasks]

        for fut in as_completed(futures):
            disp_id, tag = fut.result()
            print(f"[DONE] disp {disp_id:03d} {tag}")

    print("All displacement calculations finished.")


if __name__ == "__main__":
    main()

