#!/usr/bin/env bash
set -e

mace_run_train --name="dftbmace_diff_31_L1_c2_e1" \
--device=cuda  \
--train_file="diff_train.xyz"   \
--E0s="{1:0.00, 6:0.00, 7:0.00, 8:0.00, 9:0.00, 12:0.00, 13:0.00, 14:0.00, 15:0.00, 16:0.00, 17:0.00, 29: 0.00, 35:0.00}" \
--valid_fraction=0.1 \
--model="MACE"     \
--r_max=6.0     \
--forces_weight=10     \
--energy_weight=1     \
--energy_key="energy"     \
--forces_key="forces"     \
--scheduler_patience=15     \
--patience=30     \
--eval_interval=4    \
--ema     \
--default_dtype="float32"     \
--seed=123     \
--restart_latest     \
--save_cpu  \
--error_table='PerAtomMAE'   \
--lr 0.005 \
--batch_size=16    \
--valid_batch_size=16     \
--max_num_epochs=400     \
--num_interactions=3     \
--num_channels=64    \
--max_L=1 \
--correlation=2 \
--max_ell=1 \
