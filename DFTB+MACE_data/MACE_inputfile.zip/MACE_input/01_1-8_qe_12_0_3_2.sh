#!/usr/bin/env bash
set -e

mace_run_train --name="dftbmace_qe_12_L0_c3_e2" \
--device=cuda  \
--train_file="qe_train.xyz"   \
--E0s="average" \
--valid_fraction=0.1 \
--model="MACE"     \
--r_max=6.0     \
--forces_weight=10     \
--energy_weight=1     \
--energy_key="energy"     \
--forces_key="forces"     \
--scheduler_patience=15     \
--patience=30     \
--eval_interval=4    \
--ema     \
--default_dtype="float32"     \
--seed=123     \
--restart_latest     \
--save_cpu  \
--error_table='PerAtomMAE'   \
--lr 0.005 \
--batch_size=16    \
--valid_batch_size=16     \
--max_num_epochs=400     \
--num_interactions=1     \
--num_channels=8    \
--max_L=0 \
--correlation=3 \
--max_ell=2 \
